const express = require('express');
const path = require('path');

const app = express();

app.use(express.static(path.join(__dirname, 'public')));

app.use('/2026', express.static(path.join(__dirname, 'public', 'photos')));

const PORT = process.env.PORT ||8099;
app.listen(PORT, () => {
  console.log(`Express server listening on port ${PORT}`);
});