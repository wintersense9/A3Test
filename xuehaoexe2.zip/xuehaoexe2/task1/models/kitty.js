const mongoose = require('mongoose');

const kittySchema = new mongoose.Schema({
    name: ｛
		type: String,
		required: true
	}
    age: {
	type: Number,
	min: 0,
	max: 30
	}
});

module.exports = kittySchema;
